<?php
include("../Connections/conn_games.php");
mysqli_select_db($conn_games,$database_conn);
$consulta = "SELECT * FROM tbdownload ORDER BY nome_download ASC";
$lista = $conn_games->query($consulta);
$row = $lista->fetch_assoc();
$totalRows = ($lista)->num_rows;
?>
<!doctype html>
<html lang="pt-br">

<head>
    <title>Lista de Downloads</title>
    <meta charset="utf-8">
    <!-- Bootstrap -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <main class="container">
        <h1 class="breadcrumb alert-primary">Downloads</h1>
        <div class="col-xs-12 col-sm-6 col-sm-offset-2 col-md-8 col-md-offset-2">
            <table class="table table-hover table-condensed tbopacidade">
                <thead>
                    <!-- Cabeçalho da Tabela -->
                    <tr>
                        <th hidden>ID</th><!-- Cabeça da Coluna -->
                        <th>NOME</th>
                        <th>PLATAFORMA</th>
                        <th>IMAGEM</th>
                        <th>ARQUIVO</th>
                        <th>
                            <a href="insere_downloads.php" target="_self" class="btn btn-block btn-success btn-xs" role="button">
                                <span class="hidden-xs">ADICIONAR<br>
                                <!--<span class=""></span>-->
                                </span>
                            </a>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Corpo da Tabela -->
                    <?php do { ?>
                    <tr>
                        <td hidden><?php echo $row['id_download']; ?></td>
                        <td><?php echo $row['nome_download']; ?></td>
                        <td><?php echo $row['plataforma_download']; ?></td>
                        <td><?php
                      //if($row['nivel_usuario']=='sup'){
                          //echo ("<span class=''></span>");
                      //}else
                      ///if($row['nivel_usuario']=='com'){
                          //echo ("<span class=''></span>");
                      //};
                    ?>
                            <img src="../imagens/<?php echo $row['imagem_download']; ?>" alt="<?php echo $row['imagem_download']; ?>" width="100px">
                        </td>
                        <td>
                            <a href="../games_download/<?php echo $row['arquivo_download']; ?>" download>Baixar</a>
                        </td>
                        <td>
                            <a href="atualiza_downloads.php?id_download=<?php echo $row['id_download']; ?>" target="_self" class="btn btn-primary btn-block btn-xs" role="button">
                                <span class="hidden-xs">ALTERAR<br></span>
                                <!--<span class=""></span>-->
                            </a>
                            <button data-nome="<?php echo $row['nome_download']; ?>" data-id="<?php echo $row['id_download']; ?>" class="delete btn btn-danger btn-block btn-xs">
                                <span class="hidden-xs">EXCLUIR<br></span>
                                <!--<span class=""></span>-->
                            </button>
                        </td>
                    </tr>
                    <?php } while ($row = $lista->fetch_assoc()); ?>
                </tbody>
            </table>
    </main>
    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-danger">ATENÇÃO!</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    Deseja Mesmo EXCLUIR o Download?
                    <h4><span class="nome text-danger"></span></h4>
                </div>
                <div class="modal-footer">
                    <a href="#" type="button" class="btn btn-danger delete-yes">Confirmar</a>
                    <button type="button" class="btn btn-success" data-dismiss="modal">
                        Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- Script para o Modal -->
    <script type="text/javascript">
        $('.delete').on('click', function() {
            var nome = $(this).data('nome');
            // Buscar o Valor do Atributo data-nome
            var id = $(this).data('id');
            // Buscar o Valor do Atributo data-id
            $('span.nome').text(nome);
            // Inserir o Nome do Item na Pergunta de Confirmação
            $('a.delete-yes').attr('href', 'exclui_downloads.php?id_download=' + id);
            // Mudar Dinâmicamente o id do Link no Botão Confirmar
            $('#myModal').modal('show'); // Modal Abre
        });
    </script>
</body>

</html>
<?php mysqli_free_result($lista); ?>